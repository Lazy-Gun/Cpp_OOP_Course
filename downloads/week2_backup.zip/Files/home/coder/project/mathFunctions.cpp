int sum(int a, int b)
{
    int c = a + b;
    return c;
}

int product(int a, int b)
{
    int c = a * b;
    return c;
}