#include <iostream>

int sum(int a, int b);
int product(int a, int b);

int main()
{

    std:: cout << "mathFunc sum() = " << sum(4, 5) << std::endl;
    std:: cout << "mathFunc product() = " << product(4, 5) << std::endl;
}
